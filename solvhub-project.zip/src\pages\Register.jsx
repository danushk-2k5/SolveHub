import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { User, Wrench, Shield, Eye, EyeOff, CheckCircle } from 'lucide-react';

const Register = () => {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        phone: '',
        password: '',
        confirmPassword: '',
        role: 'customer'
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);
    const [step, setStep] = useState(1);
    const { register } = useAuth();
    const navigate = useNavigate();

    const roles = [
        {
            id: 'customer',
            title: 'Customer',
            description: 'Find technicians for your needs',
            icon: User,
            color: 'blue'
        },
        {
            id: 'technician',
            title: 'Technician',
            description: 'Offer your professional services',
            icon: Wrench,
            color: 'green'
        }
    ];

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
        if (error) setError('');
    };

    const handleRoleSelect = (role) => {
        setFormData({ ...formData, role });
    };

    const validateStep1 = () => {
        if (!formData.name.trim()) {
            setError('Please enter your full name');
            return false;
        }
        if (!formData.phone.trim() || formData.phone.length < 10) {
            setError('Please enter a valid phone number');
            return false;
        }
        if (!formData.email.trim() || !formData.email.includes('@')) {
            setError('Please enter a valid email address');
            return false;
        }
        return true;
    };

    const validateStep2 = () => {
        if (!formData.password || formData.password.length < 6) {
            setError('Password must be at least 6 characters');
            return false;
        }
        if (formData.password !== formData.confirmPassword) {
            setError('Passwords do not match');
            return false;
        }
        return true;
    };

    const handleNext = () => {
        if (step === 1 && validateStep1()) {
            setStep(2);
            setError('');
        }
    };

    const handleBack = () => {
        setStep(1);
        setError('');
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validateStep2()) return;

        setLoading(true);
        setError('');

        const result = await register({
            name: formData.name,
            email: formData.email,
            phone: formData.phone,
            password: formData.password,
            role: formData.role
        });

        setLoading(false);

        if (result.success) {
            if (formData.role === 'technician') {
                navigate('/technician/dashboard');
            } else {
                navigate('/customer/dashboard');
            }
        } else {
            setError(result.error || 'Registration failed. Please try again.');
        }
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-cyan-50 via-blue-50 to-indigo-50 flex items-center justify-center py-12 px-4">
            <div className="max-w-md w-full">
                {/* Logo */}
                <div className="text-center mb-8">
                    <Link to="/" className="inline-flex items-center space-x-2">
                        <div className="w-10 h-10 bg-gradient-to-br from-primary-500 to-primary-600 rounded-xl flex items-center justify-center">
                            <Wrench className="w-6 h-6 text-white" />
                        </div>
                        <span className="text-2xl font-bold bg-gradient-to-r from-primary-600 to-primary-800 bg-clip-text text-transparent">
                            SolvHub
                        </span>
                    </Link>
                </div>

                {/* Main Card */}
                <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
                    {/* Progress Bar */}
                    <div className="bg-gray-50 px-6 py-4 border-b border-gray-100">
                        <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                                    step >= 1 ? 'bg-primary-600 text-white' : 'bg-gray-200 text-gray-500'
                                }`}>
                                    {step > 1 ? <CheckCircle className="w-5 h-5" /> : '1'}
                                </div>
                                <span className={`text-sm font-medium ${step >= 1 ? 'text-gray-900' : 'text-gray-500'}`}>
                                    Details
                                </span>
                            </div>
                            <div className="flex-1 h-1 mx-4 bg-gray-200 rounded-full">
                                <div className={`h-full bg-primary-600 rounded-full transition-all duration-300 ${
                                    step >= 2 ? 'w-full' : 'w-0'
                                }`} />
                            </div>
                            <div className="flex items-center space-x-2">
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                                    step >= 2 ? 'bg-primary-600 text-white' : 'bg-gray-200 text-gray-500'
                                }`}>
                                    2
                                </div>
                                <span className={`text-sm font-medium ${step >= 2 ? 'text-gray-900' : 'text-gray-500'}`}>
                                    Password
                                </span>
                            </div>
                        </div>
                    </div>

                    <div className="p-6">
                        {error && (
                            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center space-x-2">
                                <div className="w-5 h-5 rounded-full bg-red-100 flex items-center justify-center">
                                    <span className="text-red-600 text-xs">!</span>
                                </div>
                                <p className="text-sm text-red-600">{error}</p>
                            </div>
                        )}

                        {step === 1 ? (
                            <div className="space-y-6">
                                {/* Role Selection */}
                                <div>
                                    <label className="block text-sm font-semibold text-gray-900 mb-3">
                                        I am a
                                    </label>
                                    <div className="space-y-3">
                                        {roles.map((role) => {
                                            const Icon = role.icon;
                                            const isSelected = formData.role === role.id;
                                            const borderClass = isSelected 
                                                ? (role.color === 'blue' ? 'border-blue-500' : 'border-green-500')
                                                : 'border-gray-200';
                                            const bgClass = isSelected
                                                ? (role.color === 'blue' ? 'bg-blue-50' : 'bg-green-50')
                                                : 'hover:bg-gray-50';
                                            const iconBgClass = isSelected
                                                ? (role.color === 'blue' ? 'bg-blue-100 text-blue-600' : 'bg-green-100 text-green-600')
                                                : 'bg-gray-100 text-gray-500';
                                            const textClass = isSelected ? 'text-gray-900' : 'text-gray-700';
                                            const checkClass = isSelected
                                                ? (role.color === 'blue' ? 'text-blue-600' : 'text-green-600')
                                                : '';
                                            return (
                                                <button
                                                    key={role.id}
                                                    type="button"
                                                    onClick={() => handleRoleSelect(role.id)}
                                                    className={`w-full p-4 rounded-xl border-2 text-left transition-all duration-200 ${borderClass} ${bgClass} hover:border-gray-300`}
                                                >
                                                    <div className="flex items-center space-x-3">
                                                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${iconBgClass}`}>
                                                            <Icon className="w-5 h-5" />
                                                        </div>
                                                        <div>
                                                            <p className={`font-semibold ${textClass}`}>
                                                                {role.title}
                                                            </p>
                                                            <p className="text-sm text-gray-500">
                                                                {role.description}
                                                            </p>
                                                        </div>
                                                        {isSelected && (
                                                            <div className="ml-auto">
                                                                <CheckCircle className={`w-5 h-5 ${checkClass}`} />
                                                            </div>
                                                        )}
                                                    </div>
                                                </button>
                                            );
                                        })}
                                    </div>
                                </div>

                                {/* Form Fields */}
                                <div className="space-y-4">
                                    <div>
                                        <label htmlFor="name" className="block text-sm font-semibold text-gray-900 mb-2">
                                            Full Name
                                        </label>
                                        <input
                                            id="name"
                                            name="name"
                                            type="text"
                                            placeholder="Enter your full name"
                                            required
                                            value={formData.name}
                                            onChange={handleChange}
                                            className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                                        />
                                    </div>

                                    <div>
                                        <label htmlFor="phone" className="block text-sm font-semibold text-gray-900 mb-2">
                                            Phone Number
                                        </label>
                                        <div className="relative">
                                            <span className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500 font-medium">
                                                +91
                                            </span>
                                            <input
                                                id="phone"
                                                name="phone"
                                                type="tel"
                                                placeholder="XXXXXXXXXX"
                                                required
                                                value={formData.phone}
                                                onChange={handleChange}
                                                className="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                                            />
                                        </div>
                                    </div>

                                    <div>
                                        <label htmlFor="email" className="block text-sm font-semibold text-gray-900 mb-2">
                                            Email
                                        </label>
                                        <input
                                            id="email"
                                            name="email"
                                            type="email"
                                            placeholder="your@email.com"
                                            required
                                            value={formData.email}
                                            onChange={handleChange}
                                            className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                                        />
                                    </div>
                                </div>

                                <button
                                    type="button"
                                    onClick={handleNext}
                                    className="w-full py-3.5 bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-semibold rounded-xl hover:from-blue-600 hover:to-cyan-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-all shadow-lg shadow-primary-500/30"
                                >
                                    Continue
                                </button>
                            </div>
                        ) : (
                            <form onSubmit={handleSubmit} className="space-y-6">
                                <div className="text-center mb-6">
                                    <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-3">
                                        <Shield className="w-6 h-6 text-primary-600" />
                                    </div>
                                    <h3 className="text-lg font-semibold text-gray-900">Create Password</h3>
                                    <p className="text-sm text-gray-500">Secure your account</p>
                                </div>

                                <div className="space-y-4">
                                    <div>
                                        <label htmlFor="password" className="block text-sm font-semibold text-gray-900 mb-2">
                                            Password
                                        </label>
                                        <div className="relative">
                                            <input
                                                id="password"
                                                name="password"
                                                type={showPassword ? 'text' : 'password'}
                                                placeholder="Create a strong password"
                                                required
                                                value={formData.password}
                                                onChange={handleChange}
                                                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all pr-12"
                                            />
                                            <button
                                                type="button"
                                                onClick={() => setShowPassword(!showPassword)}
                                                className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                                            >
                                                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                                            </button>
                                        </div>
                                        <p className="mt-1 text-xs text-gray-500">
                                            Must be at least 6 characters
                                        </p>
                                    </div>

                                    <div>
                                        <label htmlFor="confirmPassword" className="block text-sm font-semibold text-gray-900 mb-2">
                                            Confirm Password
                                        </label>
                                        <div className="relative">
                                            <input
                                                id="confirmPassword"
                                                name="confirmPassword"
                                                type={showConfirmPassword ? 'text' : 'password'}
                                                placeholder="Confirm your password"
                                                required
                                                value={formData.confirmPassword}
                                                onChange={handleChange}
                                                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all pr-12"
                                            />
                                            <button
                                                type="button"
                                                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                                                className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                                            >
                                                {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <div className="flex space-x-3">
                                    <button
                                        type="button"
                                        onClick={handleBack}
                                        className="flex-1 py-3.5 border border-gray-300 text-gray-700 font-semibold rounded-xl hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 transition-all"
                                    >
                                        Back
                                    </button>
                                    <button
                                        type="submit"
                                        disabled={loading}
                                        className="flex-1 py-3.5 bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-semibold rounded-xl hover:from-blue-600 hover:to-cyan-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-all shadow-lg shadow-primary-500/30 disabled:opacity-50 disabled:cursor-not-allowed"
                                    >
                                        {loading ? 'Creating Account...' : 'Create Account'}
                                    </button>
                                </div>
                            </form>
                        )}
                    </div>

                    {/* Footer */}
                    <div className="px-6 py-4 bg-gray-50 border-t border-gray-100">
                        <div className="flex items-center justify-center space-x-2 text-sm text-gray-500">
                            <Shield className="w-4 h-4" />
                            <span>Secure & Encrypted</span>
                        </div>
                        <p className="text-center text-sm text-gray-500 mt-3">
                            Already have an account?{' '}
                            <Link to="/login" className="font-semibold text-primary-600 hover:text-primary-500">
                                Sign in
                            </Link>
                        </p>
                    </div>
                </div>

                {/* Trust Badges */}
                <div className="mt-8 flex items-center justify-center space-x-6 text-gray-400">
                    <div className="flex items-center space-x-1">
                        <Shield className="w-4 h-4" />
                        <span className="text-xs">SSL Secured</span>
                    </div>
                    <div className="flex items-center space-x-1">
                        <CheckCircle className="w-4 h-4" />
                        <span className="text-xs">Verified</span>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Register;