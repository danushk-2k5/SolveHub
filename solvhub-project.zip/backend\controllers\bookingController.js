const Booking = require('../models/Booking');
const Technician = require('../models/Technician');
const Review = require('../models/Review');

// @desc    Get available time slots for a technician on a specific date
// @route   GET /api/bookings/availability/:technicianId
// @access  Public
exports.getAvailableSlots = async (req, res, next) => {
    try {
        const { technicianId } = req.params;
        const { date } = req.query;

        if (!date) {
            return res.status(400).json({ message: 'Please provide a date' });
        }

        const technician = await Technician.findById(technicianId);
        if (!technician) {
            return res.status(404).json({ message: 'Technician not found' });
        }

        // Check if technician is available on this date
        const requestedDate = new Date(date);
        const dayOfWeek = requestedDate.toLocaleDateString('en-US', { weekday: 'lowercase' });
        
        // Get technician's working hours for this day
        const workingHours = technician.workingHours?.[dayOfWeek];
        
        if (!workingHours || !workingHours.start || !workingHours.end) {
            return res.status(200).json({
                success: true,
                available: false,
                message: 'Technician is not available on this day',
                slots: []
            });
        }

        // Get all bookings for this technician on this date
        const startOfDay = new Date(date);
        startOfDay.setHours(0, 0, 0, 0);
        const endOfDay = new Date(date);
        endOfDay.setHours(23, 59, 59, 999);

        const bookings = await Booking.find({
            technicianId,
            bookingDate: { $gte: startOfDay, $lte: endOfDay },
            status: { $nin: ['cancelled'] }
        });

        // Generate all possible time slots
        const allSlots = [];
        const [startHour, startMin] = workingHours.start.split(':').map(Number);
        const [endHour, endMin] = workingHours.end.split(':').map(Number);

        let currentHour = startHour;
        let currentMin = startMin;

        while (currentHour < endHour || (currentHour === endHour && currentMin < endMin)) {
            const timeString = `${currentHour.toString().padStart(2, '0')}:${currentMin.toString().padStart(2, '0')}`;
            const displayTime = formatTime12Hour(timeString);
            allSlots.push({
                time: timeString,
                display: displayTime,
                available: true
            });
            
            currentMin += 60; // Add 1 hour
            if (currentMin >= 60) {
                currentHour += Math.floor(currentMin / 60);
                currentMin = currentMin % 60;
            }
        }

        // Mark booked slots as unavailable
        const bookedTimes = bookings.map(b => b.bookingTime);
        const availableSlots = allSlots.map(slot => ({
            ...slot,
            available: !bookedTimes.includes(slot.time)
        }));

        res.status(200).json({
            success: true,
            date,
            workingHours,
            slots: availableSlots
        });
    } catch (error) {
        next(error);
    }
};

// Helper function to format time in 12-hour format
function formatTime12Hour(time24) {
    const [hours, minutes] = time24.split(':').map(Number);
    const period = hours >= 12 ? 'PM' : 'AM';
    const hours12 = hours % 12 || 12;
    return `${hours12}:${minutes.toString().padStart(2, '0')} ${period}`;
}

// @desc    Create new booking
// @route   POST /api/bookings
// @access  Private (Customer)
exports.createBooking = async (req, res, next) => {
    try {
        const {
            technicianId,
            serviceType,
            description,
            bookingDate,
            bookingTime,
            location,
            estimatedCost
        } = req.body;

        // Verify technician exists and is available
        const technician = await Technician.findById(technicianId);
        if (!technician) {
            return res.status(404).json({ message: 'Technician not found' });
        }

        if (!technician.isAvailable) {
            return res.status(400).json({ message: 'Technician is not available' });
        }

        const booking = await Booking.create({
            customerId: req.user.id,
            technicianId,
            serviceType,
            description,
            bookingDate,
            bookingTime,
            location,
            estimatedCost: estimatedCost || technician.hourlyRate
        });

        await booking.populate([
            { path: 'customerId', select: 'name email phone' },
            { path: 'technicianId', populate: { path: 'userId', select: 'name email phone' } }
        ]);

        res.status(201).json({
            success: true,
            data: booking
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Get customer bookings
// @route   GET /api/bookings/customer
// @access  Private (Customer)
exports.getCustomerBookings = async (req, res, next) => {
    try {
        const { status, page = 1, limit = 10 } = req.query;

        let query = { customerId: req.user.id };
        if (status) {
            query.status = status;
        }

        const pageNum = parseInt(page);
        const limitNum = parseInt(limit);
        const skip = (pageNum - 1) * limitNum;

        const bookings = await Booking.find(query)
            .populate('technicianId', 'userId rating totalReviews skills')
            .populate({
                path: 'technicianId',
                populate: {
                    path: 'userId',
                    select: 'name email phone avatar'
                }
            })
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(limitNum);

        const total = await Booking.countDocuments(query);

        res.json({
            success: true,
            count: bookings.length,
            total,
            page: pageNum,
            pages: Math.ceil(total / limitNum),
            data: bookings
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Get technician bookings
// @route   GET /api/bookings/technician
// @access  Private (Technician)
exports.getTechnicianBookings = async (req, res, next) => {
    try {
        const { status, page = 1, limit = 10 } = req.query;

        // Get technician profile
        const technician = await Technician.findOne({ userId: req.user.id });
        if (!technician) {
            return res.status(404).json({ message: 'Technician profile not found' });
        }

        let query = { technicianId: technician._id };
        if (status) {
            query.status = status;
        }

        const pageNum = parseInt(page);
        const limitNum = parseInt(limit);
        const skip = (pageNum - 1) * limitNum;

        const bookings = await Booking.find(query)
            .populate('customerId', 'name email phone')
            .sort({ bookingDate: 1, bookingTime: 1 })
            .skip(skip)
            .limit(limitNum);

        const total = await Booking.countDocuments(query);

        res.json({
            success: true,
            count: bookings.length,
            total,
            page: pageNum,
            pages: Math.ceil(total / limitNum),
            data: bookings
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Get single booking
// @route   GET /api/bookings/:id
// @access  Private
exports.getBooking = async (req, res, next) => {
    try {
        const booking = await Booking.findById(req.params.id)
            .populate('customerId', 'name email phone')
            .populate({
                path: 'technicianId',
                populate: { path: 'userId', select: 'name email phone avatar' }
            });

        if (!booking) {
            return res.status(404).json({ message: 'Booking not found' });
        }

        // Check if user is authorized to view
        const isCustomer = booking.customerId._id.toString() === req.user.id;
        const technician = await Technician.findOne({ userId: req.user.id });
        const isTechnician = technician && technician._id.toString() === booking.technicianId._id.toString();
        const isAdmin = req.user.role === 'admin';

        if (!isCustomer && !isTechnician && !isAdmin) {
            return res.status(403).json({ message: 'Not authorized to view this booking' });
        }

        // Get review if exists
        const review = await Review.findOne({ bookingId: booking._id });

        res.json({
            success: true,
            data: { ...booking.toObject(), review }
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Update booking status
// @route   PUT /api/bookings/:id/status
// @access  Private
exports.updateBookingStatus = async (req, res, next) => {
    try {
        const { status, cancellationReason, finalCost, technicianNotes } = req.body;

        let booking = await Booking.findById(req.params.id);

        if (!booking) {
            return res.status(404).json({ message: 'Booking not found' });
        }

        // Determine authorization
        let isAuthorized = false;

        if (req.user.role === 'admin') {
            isAuthorized = true;
        } else if (req.user.role === 'customer' && booking.customerId.toString() === req.user.id) {
            // Customer can only cancel
            if (status === 'cancelled') {
                isAuthorized = true;
            }
        } else {
            // Check if technician owns this booking
            const technician = await Technician.findOne({ userId: req.user.id });
            if (technician && technician._id.toString() === booking.technicianId.toString()) {
                isAuthorized = true;
            }
        }

        if (!isAuthorized) {
            return res.status(403).json({ message: 'Not authorized to update this booking' });
        }

        // Validate status transitions
        const validTransitions = {
            pending: ['accepted', 'cancelled'],
            accepted: ['in_progress', 'cancelled'],
            in_progress: ['completed', 'cancelled'],
            completed: [],
            cancelled: []
        };

        if (!validTransitions[booking.status].includes(status)) {
            return res.status(400).json({
                message: `Cannot change status from ${booking.status} to ${status}`
            });
        }

        booking.status = status;

        if (status === 'accepted') {
            booking.acceptedAt = new Date();
        } else if (status === 'completed') {
            booking.completedAt = new Date();
            if (finalCost) booking.finalCost = finalCost;
        } else if (status === 'cancelled') {
            booking.cancelledAt = new Date();
            booking.cancellationReason = cancellationReason;
        }

        if (technicianNotes && req.user.role === 'technician') {
            booking.technicianNotes = technicianNotes;
        }

        await booking.save();

        await booking.populate([
            { path: 'customerId', select: 'name email phone' },
            { path: 'technicianId', populate: { path: 'userId', select: 'name email phone' } }
        ]);

        res.json({
            success: true,
            data: booking
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Cancel booking
// @route   PUT /api/bookings/:id/cancel
// @access  Private
exports.cancelBooking = async (req, res, next) => {
    try {
        const { cancellationReason } = req.body;

        const booking = await Booking.findById(req.params.id);

        if (!booking) {
            return res.status(404).json({ message: 'Booking not found' });
        }

        // Check ownership
        const isCustomer = booking.customerId.toString() === req.user.id;
        const technician = await Technician.findOne({ userId: req.user.id });
        const isTechnician = technician && technician._id.toString() === booking.technicianId.toString();

        if (!isCustomer && !isTechnician && req.user.role !== 'admin') {
            return res.status(403).json({ message: 'Not authorized' });
        }

        // Can only cancel pending or accepted bookings
        if (!['pending', 'accepted'].includes(booking.status)) {
            return res.status(400).json({ message: 'Cannot cancel this booking' });
        }

        booking.status = 'cancelled';
        booking.cancelledAt = new Date();
        booking.cancellationReason = cancellationReason;

        await booking.save();

        res.json({
            success: true,
            message: 'Booking cancelled successfully',
            data: booking
        });
    } catch (error) {
        next(error);
    }
};
