const Technician = require('../models/Technician');
const User = require('../models/User');

// @desc    Get all technicians
// @route   GET /api/technicians
// @access  Public
exports.getTechnicians = async (req, res, next) => {
    try {
        const { skill, lat, lng, radius = 5000, page = 1, limit = 10 } = req.query;

        let query = { isVerified: true, isAvailable: true };

        // Filter by skill
        if (skill) {
            query.skills = { $regex: skill, $options: 'i' };
        }

        let technicians;

        // If location provided, use geospatial query
        if (lat && lng) {
            technicians = await Technician.find({
                ...query,
                location: {
                    $near: {
                        $geometry: {
                            type: 'Point',
                            coordinates: [parseFloat(lng), parseFloat(lat)]
                        },
                        $maxDistance: parseInt(radius) // in meters
                    }
                }
            }).populate('userId', 'name email phone avatar');
        } else {
            // Regular pagination
            const pageNum = parseInt(page);
            const limitNum = parseInt(limit);
            const skip = (pageNum - 1) * limitNum;

            technicians = await Technician.find(query)
                .populate('userId', 'name email phone avatar')
                .skip(skip)
                .limit(limitNum)
                .sort({ rating: -1, totalReviews: -1 });
        }

        // Calculate distance for each technician if location provided
        const techniciansWithDistance = technicians.map(tech => {
            const techObj = tech.toObject();
            if (lat && lng && tech.location && tech.location.coordinates) {
                techObj.distance = calculateDistance(
                    parseFloat(lat),
                    parseFloat(lng),
                    tech.location.coordinates[1],
                    tech.location.coordinates[0]
                );
            }
            return techObj;
        });

        res.json({
            success: true,
            count: technicians.length,
            data: techniciansWithDistance
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Get single technician
// @route   GET /api/technicians/:id
// @access  Public
exports.getTechnician = async (req, res, next) => {
    try {
        const technician = await Technician.findById(req.params.id)
            .populate('userId', 'name email phone avatar');

        if (!technician) {
            return res.status(404).json({ message: 'Technician not found' });
        }

        res.json({
            success: true,
            data: technician
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Create technician profile
// @route   POST /api/technicians
// @access  Private (Technician)
exports.createTechnician = async (req, res, next) => {
    try {
        // Check if already has profile
        const existingProfile = await Technician.findOne({ userId: req.user.id });
        if (existingProfile) {
            return res.status(400).json({ message: 'Technician profile already exists' });
        }

        const {
            skills,
            experience,
            bio,
            serviceArea,
            location,
            hourlyRate,
            certifications,
            workingHours
        } = req.body;

        const technician = await Technician.create({
            userId: req.user.id,
            skills,
            experience,
            bio,
            serviceArea,
            location,
            hourlyRate,
            certifications,
            workingHours
        });

        res.status(201).json({
            success: true,
            data: technician
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Update technician profile
// @route   PUT /api/technicians/:id
// @access  Private (Technician)
exports.updateTechnician = async (req, res, next) => {
    try {
        let technician = await Technician.findById(req.params.id);

        if (!technician) {
            return res.status(404).json({ message: 'Technician not found' });
        }

        // Make sure user owns the profile
        if (technician.userId.toString() !== req.user.id) {
            return res.status(403).json({ message: 'Not authorized to update this profile' });
        }

        const {
            skills,
            experience,
            bio,
            serviceArea,
            location,
            isAvailable,
            hourlyRate,
            profilePhoto,
            certifications,
            workingHours
        } = req.body;

        technician = await Technician.findByIdAndUpdate(
            req.params.id,
            {
                skills,
                experience,
                bio,
                serviceArea,
                location,
                isAvailable,
                hourlyRate,
                profilePhoto,
                certifications,
                workingHours
            },
            { new: true, runValidators: true }
        );

        res.json({
            success: true,
            data: technician
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Get current technician's profile
// @route   GET /api/technicians/me/profile
// @access  Private (Technician)
exports.getMyProfile = async (req, res, next) => {
    try {
        const technician = await Technician.findOne({ userId: req.user.id })
            .populate('userId', 'name email phone avatar');

        if (!technician) {
            return res.status(404).json({ message: 'Technician profile not found' });
        }

        res.json({
            success: true,
            data: technician
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Update availability status
// @route   PUT /api/technicians/availability
// @access  Private (Technician)
exports.updateAvailability = async (req, res, next) => {
    try {
        const { isAvailable } = req.body;

        const technician = await Technician.findOne({ userId: req.user.id });

        if (!technician) {
            return res.status(404).json({ message: 'Technician profile not found' });
        }

        technician.isAvailable = isAvailable;
        await technician.save();

        res.json({
            success: true,
            data: { isAvailable: technician.isAvailable }
        });
    } catch (error) {
        next(error);
    }
};

// Helper function to calculate distance (Haversine formula)
function calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // Radius of the earth in km
    const dLat = deg2rad(lat2 - lat1);
    const dLon = deg2rad(lon2 - lon1);
    const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
        Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const d = R * c; // Distance in km
    return Math.round(d * 10) / 10;
}

function deg2rad(deg) {
    return deg * (Math.PI / 180);
}
