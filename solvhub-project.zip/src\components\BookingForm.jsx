import { useState, useEffect } from 'react';
import { bookingAPI } from '../services/api';

const BookingForm = ({ technician, onSubmit, onCancel }) => {
    const [formData, setFormData] = useState({
        serviceType: '',
        description: '',
        bookingDate: '',
        bookingTime: '',
        address: ''
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [availableSlots, setAvailableSlots] = useState([]);
    const [loadingSlots, setLoadingSlots] = useState(false);
    const [selectedTechnician, setSelectedTechnician] = useState(null);

    const serviceTypes = [
        'Electrical Repair',
        'Electrical Installation',
        'Wiring',
        'Lighting',
        'Power Outlets',
        'Circuit Breaker',
        'Other'
    ];

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
        
        // Fetch available slots when date changes
        if (name === 'bookingDate' && value && technician?._id) {
            fetchAvailableSlots(value);
        }
        // Reset time when date changes
        if (name === 'bookingDate') {
            setFormData(prev => ({ ...prev, bookingTime: '' }));
        }
    };

    const fetchAvailableSlots = async (date) => {
        if (!technician?._id) return;
        
        setLoadingSlots(true);
        try {
            const response = await bookingAPI.getAvailableSlots(technician._id, date);
            if (response.data.success) {
                setAvailableSlots(response.data.slots || []);
            }
        } catch (err) {
            console.error('Error fetching slots:', err);
            setAvailableSlots([]);
        } finally {
            setLoadingSlots(false);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setLoading(true);

        try {
            await onSubmit({
                ...formData,
                technicianId: technician._id,
                location: {
                    address: formData.address
                }
            });
        } catch (err) {
            setError(err.response?.data?.message || 'Failed to create booking');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl font-bold mb-6">Book Service</h2>
            
            <div className="mb-4 p-4 bg-gray-50 rounded-lg">
                <h3 className="font-semibold">{technician.userId?.name || 'Technician'}</h3>
                <p className="text-sm text-gray-600">
                    {technician.skills?.join(', ')}
                </p>
                <p className="text-sm text-gray-600">
                    Rating: {technician.rating?.toFixed(1) || '0'} ({technician.totalReviews || 0} reviews)
                </p>
            </div>

            <form onSubmit={handleSubmit}>
                {error && (
                    <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-md">
                        {error}
                    </div>
                )}

                <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                        Service Type
                    </label>
                    <select
                        name="serviceType"
                        value={formData.serviceType}
                        onChange={handleChange}
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                    >
                        <option value="">Select a service</option>
                        {serviceTypes.map((type) => (
                            <option key={type} value={type}>
                                {type}
                            </option>
                        ))}
                    </select>
                </div>

                <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                        Description
                    </label>
                    <textarea
                        name="description"
                        value={formData.description}
                        onChange={handleChange}
                        required
                        rows="4"
                        placeholder="Describe the problem or service you need..."
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                    />
                </div>

                <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Date
                        </label>
                        <input
                            type="date"
                            name="bookingDate"
                            value={formData.bookingDate}
                            onChange={handleChange}
                            required
                            min={new Date().toISOString().split('T')[0]}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Time
                        </label>
                        {loadingSlots ? (
                            <div className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50">
                                <span className="text-sm text-gray-500">Loading available times...</span>
                            </div>
                        ) : availableSlots.length > 0 ? (
                            <select
                                name="bookingTime"
                                value={formData.bookingTime}
                                onChange={handleChange}
                                required
                                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                            >
                                <option value="">Select time</option>
                                {availableSlots.map((slot) => (
                                    <option 
                                        key={slot.time} 
                                        value={slot.time}
                                        disabled={!slot.available}
                                    >
                                        {slot.display} {!slot.available ? '(Booked)' : ''}
                                    </option>
                                ))}
                            </select>
                        ) : formData.bookingDate ? (
                            <div className="w-full px-3 py-2 border border-yellow-300 rounded-md bg-yellow-50">
                                <span className="text-sm text-yellow-700">No available slots for this date</span>
                            </div>
                        ) : (
                            <select
                                name="bookingTime"
                                value={formData.bookingTime}
                                onChange={handleChange}
                                required
                                disabled
                                className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50"
                            >
                                <option value="">Select a date first</option>
                            </select>
                        )}
                    </div>
                </div>

                <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                        Your Address
                    </label>
                    <textarea
                        name="address"
                        value={formData.address}
                        onChange={handleChange}
                        required
                        rows="2"
                        placeholder="Enter your address for the service..."
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                    />
                </div>

                <div className="flex space-x-4">
                    <button
                        type="submit"
                        disabled={loading}
                        className="flex-1 bg-primary-600 text-white py-2 px-4 rounded-md hover:bg-primary-700 disabled:bg-gray-400"
                    >
                        {loading ? 'Booking...' : 'Confirm Booking'}
                    </button>
                    <button
                        type="button"
                        onClick={onCancel}
                        className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
                    >
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    );
};

export default BookingForm;
