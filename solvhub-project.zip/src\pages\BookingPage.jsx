import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { technicianAPI, bookingAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import BookingForm from '../components/BookingForm';
import { ArrowLeft, MapPin, Star, Clock, CheckCircle, Phone, Zap, Droplets, Hammer, Paintbrush, Car, Home, Scissors, ChefHat, Laptop, Bug, Trees, Flame } from 'lucide-react';

// Static technician data (same as FindTechnicians)
const staticTechnicians = [
    {
        _id: '1',
        name: 'Ramesh Kumar',
        serviceType: 'Electrician',
        category: 'electrician',
        rating: 4.8,
        totalReviews: 127,
        experience: 8,
        hourlyRate: 350,
        location: 'Anna Nagar, Chennai',
        distance: '2.5 km',
        image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop',
        skills: ['Wiring', 'Switch Repair', 'Fan Installation', 'Inverter Setup'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43210',
        description: 'Expert electrician with 8+ years experience in residential and commercial electrical work.',
        userId: { name: 'Ramesh Kumar', phone: '+91 98765 43210' }
    },
    {
        _id: '2',
        name: 'Suresh Patel',
        serviceType: 'Plumber',
        category: 'plumber',
        rating: 4.6,
        totalReviews: 89,
        experience: 6,
        hourlyRate: 300,
        location: 'T Nagar, Chennai',
        distance: '3.2 km',
        image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop',
        skills: ['Pipe Fitting', 'Leak Repair', 'Bathroom Fitting', 'Water Heater'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43211',
        description: 'Professional plumber specializing in bathroom fittings and pipe repairs.',
        userId: { name: 'Suresh Patel', phone: '+91 98765 43211' }
    },
    {
        _id: '3',
        name: 'Mohammed Ali',
        serviceType: 'Carpenter',
        category: 'carpenter',
        rating: 4.9,
        totalReviews: 156,
        experience: 12,
        hourlyRate: 400,
        location: 'Adyar, Chennai',
        distance: '4.1 km',
        image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop',
        skills: ['Furniture Making', 'Door Repair', 'Cabinet Work', 'Wood Polishing'],
        isAvailable: false,
        verified: true,
        phone: '+91 98765 43212',
        description: 'Master carpenter with 12 years of craftsmanship experience.',
        userId: { name: 'Mohammed Ali', phone: '+91 98765 43212' }
    },
    {
        _id: '4',
        name: 'Priya Sharma',
        serviceType: 'Painter',
        category: 'painter',
        rating: 4.7,
        totalReviews: 73,
        experience: 5,
        hourlyRate: 280,
        location: 'Velachery, Chennai',
        distance: '1.8 km',
        image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop',
        skills: ['Interior Painting', 'Exterior Painting', 'Texture Work', 'Wallpaper'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43213',
        description: 'Creative painter specializing in interior and exterior painting.',
        userId: { name: 'Priya Sharma', phone: '+91 98765 43213' }
    },
    {
        _id: '5',
        name: 'Venkatesh Rao',
        serviceType: 'AC Technician',
        category: 'technician',
        rating: 4.5,
        totalReviews: 94,
        experience: 7,
        hourlyRate: 450,
        location: 'Guindy, Chennai',
        distance: '5.3 km',
        image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=400&fit=crop',
        skills: ['AC Installation', 'AC Repair', 'Gas Refilling', 'Annual Maintenance'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43214',
        description: 'Certified AC technician with expertise in all major brands.',
        userId: { name: 'Venkatesh Rao', phone: '+91 98765 43214' }
    },
    {
        _id: '6',
        name: 'Lakshmi Devi',
        serviceType: 'Home Cleaning',
        category: 'cleaning',
        rating: 4.8,
        totalReviews: 203,
        experience: 4,
        hourlyRate: 200,
        location: 'Mylapore, Chennai',
        distance: '3.7 km',
        image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop',
        skills: ['Deep Cleaning', 'Kitchen Cleaning', 'Bathroom Cleaning', 'Sofa Cleaning'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43215',
        description: 'Professional home cleaning expert with eco-friendly products.',
        userId: { name: 'Lakshmi Devi', phone: '+91 98765 43215' }
    },
    {
        _id: '7',
        name: 'Arun Kumar',
        serviceType: 'Car Mechanic',
        category: 'mechanic',
        rating: 4.6,
        totalReviews: 112,
        experience: 9,
        hourlyRate: 500,
        location: 'Porur, Chennai',
        distance: '6.2 km',
        image: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400&h=400&fit=crop',
        skills: ['Car Service', 'Engine Repair', 'Brake Service', 'Oil Change'],
        isAvailable: false,
        verified: true,
        phone: '+91 98765 43216',
        description: 'Experienced auto mechanic specializing in all car brands.',
        userId: { name: 'Arun Kumar', phone: '+91 98765 43216' }
    },
    {
        _id: '8',
        name: 'Sunita Patel',
        serviceType: 'Beautician',
        category: 'beauty',
        rating: 4.9,
        totalReviews: 178,
        experience: 6,
        hourlyRate: 350,
        location: 'Kodambakkam, Chennai',
        distance: '2.9 km',
        image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=400&fit=crop',
        skills: ['Facial', 'Hair Styling', 'Manicure', 'Pedicure', 'Makeup'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43217',
        description: 'Professional beautician offering salon services at home.',
        userId: { name: 'Sunita Patel', phone: '+91 98765 43217' }
    },
    {
        _id: '9',
        name: 'Karthik Subramani',
        serviceType: 'Catering',
        category: 'cooking',
        rating: 4.7,
        totalReviews: 85,
        experience: 10,
        hourlyRate: 600,
        location: 'Alwarpet, Chennai',
        distance: '4.5 km',
        image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400&h=400&fit=crop',
        skills: ['South Indian', 'North Indian', 'Chinese', 'Party Catering', 'Tiffin Service'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43218',
        description: 'Professional chef with 10 years experience in multi-cuisine cooking.',
        userId: { name: 'Karthik Subramani', phone: '+91 98765 43218' }
    }
];

// More technicians
const moreTechnicians = [
    { _id: '10', name: 'Amit Sharma', serviceType: 'AC Technician', category: 'technician', rating: 4.6, totalReviews: 156, experience: 8, hourlyRate: 500, location: 'Andheri West, Mumbai', skills: ['AC Installation', 'AC Repair', 'Gas Refilling'], isAvailable: true, verified: true, phone: '+91 98765 43219', userId: { name: 'Amit Sharma', phone: '+91 98765 43219' }},
    { _id: '11', name: 'Rahul Verma', serviceType: 'Plumber', category: 'plumber', rating: 4.5, totalReviews: 98, experience: 5, hourlyRate: 350, location: 'Connaught Place, Delhi', skills: ['Pipe Fitting', 'Leak Repair'], isAvailable: true, verified: true, phone: '+91 98765 43220', userId: { name: 'Rahul Verma', phone: '+91 98765 43220' }},
    { _id: '12', name: 'Sandeep Reddy', serviceType: 'Electrician', category: 'electrician', rating: 4.8, totalReviews: 234, experience: 12, hourlyRate: 450, location: 'Banjara Hills, Hyderabad', skills: ['Wiring', 'Switchboard'], isAvailable: true, verified: true, phone: '+91 98765 43221', userId: { name: 'Sandeep Reddy', phone: '+91 98765 43221' }},
    { _id: '13', name: 'Prakash Jha', serviceType: 'Pest Control', category: 'pest_control', rating: 4.7, totalReviews: 167, experience: 7, hourlyRate: 600, location: 'Salt Lake, Kolkata', skills: ['Cockroach Control', 'Termite Treatment'], isAvailable: true, verified: true, phone: '+91 98765 43222', userId: { name: 'Prakash Jha', phone: '+91 98765 43222' }},
    { _id: '14', name: 'Nikhil Joshi', serviceType: 'Home Cleaning', category: 'cleaning', rating: 4.9, totalReviews: 312, experience: 5, hourlyRate: 250, location: 'Koregaon Park, Pune', skills: ['Deep Cleaning', 'Sanitization'], isAvailable: true, verified: true, phone: '+91 98765 43223', userId: { name: 'Nikhil Joshi', phone: '+91 98765 43223' }},
    { _id: '15', name: 'Deepak Gowda', serviceType: 'Carpenter', category: 'carpenter', rating: 4.6, totalReviews: 145, experience: 15, hourlyRate: 500, location: 'MG Road, Bangalore', skills: ['Furniture Making', 'Modular Kitchen'], isAvailable: false, verified: true, phone: '+91 98765 43224', userId: { name: 'Deepak Gowda', phone: '+91 98765 43224' }},
    { _id: '16', name: 'Vijay Malhotra', serviceType: 'Painter', category: 'painter', rating: 4.5, totalReviews: 89, experience: 6, hourlyRate: 350, location: 'Gurgaon Sector 56', skills: ['Interior Painting', 'Exterior Painting'], isAvailable: true, verified: true, phone: '+91 98765 43225', userId: { name: 'Vijay Malhotra', phone: '+91 98765 43225' }},
    { _id: '17', name: 'Anjali Iyer', serviceType: 'Beautician', category: 'beauty', rating: 4.8, totalReviews: 256, experience: 8, hourlyRate: 450, location: 'Jubilee Hills, Hyderabad', skills: ['Bridal Makeup', 'Hair Styling'], isAvailable: true, verified: true, phone: '+91 98765 43226', userId: { name: 'Anjali Iyer', phone: '+91 98765 43226' }},
    { _id: '18', name: 'Raj Singh', serviceType: 'Car Mechanic', category: 'mechanic', rating: 4.7, totalReviews: 189, experience: 11, hourlyRate: 600, location: 'Janakpuri, Delhi', skills: ['Engine Repair', 'Transmission'], isAvailable: true, verified: true, phone: '+91 98765 43227', userId: { name: 'Raj Singh', phone: '+91 98765 43227' }},
    { _id: '19', name: 'Manish Kumar', serviceType: 'Refrigerator Technician', category: 'appliance', rating: 4.6, totalReviews: 134, experience: 7, hourlyRate: 400, location: 'Vijayanagar, Bangalore', skills: ['Refrigerator Repair', 'Washing Machine'], isAvailable: true, verified: true, phone: '+91 98765 43228', userId: { name: 'Manish Kumar', phone: '+91 98765 43228' }},
    { _id: '20', name: 'Kiran Patel', serviceType: 'Gardener', category: 'gardening', rating: 4.4, totalReviews: 67, experience: 4, hourlyRate: 300, location: 'Vastrapur, Ahmedabad', skills: ['Lawn Maintenance', 'Plant Care'], isAvailable: true, verified: true, phone: '+91 98765 43229', userId: { name: 'Kiran Patel', phone: '+91 98765 43229' }},
    { _id: '21', name: 'Sanjay Thakur', serviceType: 'Chef', category: 'cooking', rating: 4.9, totalReviews: 178, experience: 12, hourlyRate: 800, location: 'Powai, Mumbai', skills: ['Biryani Specialist', 'Mughlai'], isAvailable: true, verified: true, phone: '+91 98765 43230', userId: { name: 'Sanjay Thakur', phone: '+91 98765 43230' }},
    { _id: '22', name: 'Ravi Teja', serviceType: 'TV Technician', category: 'appliance', rating: 4.5, totalReviews: 112, experience: 6, hourlyRate: 350, location: 'Ameerpet, Hyderabad', skills: ['LED Repair', 'LCD Repair'], isAvailable: true, verified: true, phone: '+91 98765 43231', userId: { name: 'Ravi Teja', phone: '+91 98765 43231' }},
    { _id: '23', name: 'Fatima Sheikh', serviceType: 'Sofa Cleaning', category: 'cleaning', rating: 4.7, totalReviews: 198, experience: 5, hourlyRate: 400, location: 'Bandra West, Mumbai', skills: ['Sofa Cleaning', 'Carpet Cleaning'], isAvailable: true, verified: true, phone: '+91 98765 43232', userId: { name: 'Fatima Sheikh', phone: '+91 98765 43232' }},
    { _id: '24', name: 'Omar Khan', serviceType: 'Pest Control', category: 'pest_control', rating: 4.6, totalReviews: 145, experience: 8, hourlyRate: 550, location: 'Whitefield, Bangalore', skills: ['Termite Control', 'Mosquito Control'], isAvailable: true, verified: true, phone: '+91 98765 43233', userId: { name: 'Omar Khan', phone: '+91 98765 43233' }}
];

// Combine all static technicians
const allStaticTechnicians = [...staticTechnicians, ...moreTechnicians];

const BookingPage = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const { isAuthenticated, user } = useAuth();
    const [technician, setTechnician] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [bookingSuccess, setBookingSuccess] = useState(false);

    useEffect(() => {
        fetchTechnician();
    }, [id]);

    const fetchTechnician = async () => {
        try {
            // First try to get from API
            const response = await technicianAPI.getById(id);
            setTechnician(response.data.data);
        } catch (err) {
            // If API fails, check if it's a static technician
            const staticTech = allStaticTechnicians.find(t => t._id === id);
            if (staticTech) {
                setTechnician({
                    ...staticTech,
                    userId: staticTech.userId,
                    profilePhoto: staticTech.image,
                    serviceArea: staticTech.location
                });
            } else {
                setError('Technician not found');
            }
        } finally {
            setLoading(false);
        }
    };

    const handleBookingSubmit = async (bookingData) => {
        try {
            // Try to create booking in database
            await bookingAPI.create(bookingData);
            setBookingSuccess(true);
            // Redirect to customer dashboard after 2 seconds
            setTimeout(() => {
                navigate('/customer/dashboard');
            }, 2000);
        } catch (err) {
            // For static technicians, show success anyway (demo mode)
            const isStaticTech = allStaticTechnicians.some(t => t._id === id);
            if (isStaticTech) {
                setBookingSuccess(true);
                setTimeout(() => {
                    navigate('/customer/dashboard');
                }, 2000);
            } else {
                throw err;
            }
        }
    };

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
            </div>
        );
    }

    if (error || !technician) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <div className="text-center">
                    <p className="text-red-600 mb-4">{error || 'Technician not found'}</p>
                    <Link to="/technicians" className="text-primary-600 hover:underline">
                        Back to Technicians
                    </Link>
                </div>
            </div>
        );
    }

    if (bookingSuccess) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-50">
                <div className="text-center bg-white p-8 rounded-2xl shadow-lg max-w-md">
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <CheckCircle className="w-8 h-8 text-green-600" />
                    </div>
                    <h2 className="text-2xl font-bold text-gray-900 mb-2">Booking Request Sent!</h2>
                    <p className="text-gray-600 mb-4">
                        Your booking request has been sent to {technician.userId?.name || 'the technician'}. 
                        They will review and accept your request shortly.
                    </p>
                    <p className="text-sm text-gray-500">Redirecting to your dashboard...</p>
                </div>
            </div>
        );
    }

    // Check if user is logged in and is a customer
    if (!isAuthenticated) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-50">
                <div className="text-center bg-white p-8 rounded-2xl shadow-lg max-w-md">
                    <h2 className="text-2xl font-bold text-gray-900 mb-4">Login Required</h2>
                    <p className="text-gray-600 mb-6">
                        Please login to book a service.
                    </p>
                    <div className="flex space-x-4 justify-center">
                        <Link
                            to="/login"
                            className="px-6 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700"
                        >
                            Login
                        </Link>
                        <Link
                            to="/register"
                            className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
                        >
                            Register
                        </Link>
                    </div>
                </div>
            </div>
        );
    }

    if (user?.role !== 'customer') {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-50">
                <div className="text-center bg-white p-8 rounded-2xl shadow-lg max-w-md">
                    <h2 className="text-2xl font-bold text-gray-900 mb-4">Customers Only</h2>
                    <p className="text-gray-600 mb-6">
                        Only customers can book services. Please login as a customer account.
                    </p>
                    <Link
                        to="/"
                        className="text-primary-600 hover:underline"
                    >
                        Go to Home
                    </Link>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-50 py-8">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                {/* Back Button */}
                <Link
                    to="/technicians"
                    className="inline-flex items-center text-gray-600 hover:text-primary-600 mb-6"
                >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back to Technicians
                </Link>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Technician Info */}
                    <div className="lg:col-span-1">
                        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                            <div className="h-48 overflow-hidden">
                                <img
                                    src={technician.profilePhoto || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop'}
                                    alt={technician.userId?.name}
                                    className="w-full h-full object-cover"
                                />
                            </div>
                            <div className="p-6">
                                <div className="flex items-center justify-between mb-2">
                                    <h2 className="text-xl font-bold text-gray-900">
                                        {technician.userId?.name || 'Technician'}
                                    </h2>
                                    {technician.isVerified && (
                                        <CheckCircle className="w-5 h-5 text-blue-500" />
                                    )}
                                </div>
                                <p className="text-primary-600 font-medium mb-4">
                                    {technician.skills?.join(', ') || 'Professional Service'}
                                </p>

                                <div className="space-y-3">
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center">
                                            <Star className="w-5 h-5 text-yellow-400 mr-1" />
                                            <span className="font-medium">{technician.rating?.toFixed(1) || '0'}</span>
                                            <span className="text-gray-500 ml-1">({technician.totalReviews || 0} reviews)</span>
                                        </div>
                                    </div>
                                    <div className="flex items-center text-gray-600">
                                        <Clock className="w-4 h-4 mr-2" />
                                        <span>{technician.experience || 0} years experience</span>
                                    </div>
                                    <div className="flex items-center text-gray-600">
                                        <MapPin className="w-4 h-4 mr-2" />
                                        <span>{technician.serviceArea || 'Service area not specified'}</span>
                                    </div>
                                    {technician.userId?.phone && (
                                        <div className="flex items-center text-gray-600">
                                            <Phone className="w-4 h-4 mr-2" />
                                            <span>{technician.userId.phone}</span>
                                        </div>
                                    )}
                                </div>

                                <div className="mt-4 pt-4 border-t border-gray-100">
                                    <div className="flex items-center justify-between">
                                        <span className="text-gray-600">Hourly Rate</span>
                                        <span className="text-2xl font-bold text-gray-900">₹{technician.hourlyRate || 0}</span>
                                    </div>
                                </div>

                                <div className={`mt-4 px-3 py-2 rounded-lg text-center ${technician.isAvailable ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                    {technician.isAvailable ? 'Available for Booking' : 'Currently Unavailable'}
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Booking Form */}
                    <div className="lg:col-span-2">
                        <BookingForm
                            technician={technician}
                            onSubmit={handleBookingSubmit}
                            onCancel={() => navigate('/technicians')}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default BookingPage;
