const mongoose = require('mongoose');

const reviewSchema = new mongoose.Schema({
    customerId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    technicianId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Technician',
        required: true
    },
    bookingId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Booking',
        required: true
    },
    rating: {
        type: Number,
        required: [true, 'Please provide a rating'],
        min: [1, 'Rating must be at least 1'],
        max: [5, 'Rating cannot be more than 5']
    },
    comment: {
        type: String,
        required: [true, 'Please provide a comment'],
        maxlength: [500, 'Comment cannot be more than 500 characters']
    },
    isVerified: {
        type: Boolean,
        default: true  // Reviews are from completed bookings, so they're verified
    }
}, { timestamps: true });

// Prevent duplicate reviews for the same booking
reviewSchema.index({ bookingId: 1 }, { unique: true });
reviewSchema.index({ technicianId: 1, createdAt: -1 });

// Static method to calculate average rating
reviewSchema.statics.calcAverageRating = async function(technicianId) {
    const stats = await this.aggregate([
        {
            $match: { technicianId: technicianId }
        },
        {
            $group: {
                _id: '$technicianId',
                nRating: { $sum: 1 },
                avgRating: { $avg: '$rating' }
            }
        }
    ]);

    if (stats.length > 0) {
        await mongoose.model('Technician').findByIdAndUpdate(technicianId, {
            rating: Math.round(stats[0].avgRating * 10) / 10,
            totalReviews: stats[0].nRating
        });
    } else {
        await mongoose.model('Technician').findByIdAndUpdate(technicianId, {
            rating: 0,
            totalReviews: 0
        });
    }
};

// Calculate average after save
reviewSchema.post('save', function() {
    this.constructor.calcAverageRating(this.technicianId);
});

// Calculate average after remove
reviewSchema.pre('remove', function(next) {
    this.constructor.calcAverageRating(this.technicianId);
    next();
});

module.exports = mongoose.model('Review', reviewSchema);
