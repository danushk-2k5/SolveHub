const protect = require('./authMiddleware');

const authorize = (...roles) => {
    return (req, res, next) => {
        if (!roles.includes(req.user.role)) {
            return res.status(403).json({
                message: `User role ${req.user.role} is not authorized to access this route`
            });
        }
        next();
    };
};

// Middleware to check if user is a technician and has a profile
const isTechnician = async (req, res, next) => {
    const Technician = require('../models/Technician');
    
    if (req.user.role !== 'technician') {
        return res.status(403).json({
            message: 'Access denied. Technician account required.'
        });
    }

    const technician = await Technician.findOne({ userId: req.user._id });
    
    if (!technician) {
        return res.status(404).json({
            message: 'Technician profile not found. Please create a profile first.'
        });
    }

    req.technician = technician;
    next();
};

module.exports = { authorize, isTechnician };
