const Review = require('../models/Review');
const Booking = require('../models/Booking');
const Technician = require('../models/Technician');

// @desc    Create review
// @route   POST /api/reviews
// @access  Private (Customer)
exports.createReview = async (req, res, next) => {
    try {
        const { technicianId, bookingId, rating, comment } = req.body;

        // Verify booking exists and belongs to user
        const booking = await Booking.findById(bookingId);
        if (!booking) {
            return res.status(404).json({ message: 'Booking not found' });
        }

        // Verify user is the customer
        if (booking.customerId.toString() !== req.user.id) {
            return res.status(403).json({ message: 'Not authorized to review this booking' });
        }

        // Verify booking is completed
        if (booking.status !== 'completed') {
            return res.status(400).json({ message: 'Can only review completed bookings' });
        }

        // Check if review already exists
        const existingReview = await Review.findOne({ bookingId });
        if (existingReview) {
            return res.status(400).json({ message: 'Review already exists for this booking' });
        }

        // Verify technician exists
        const technician = await Technician.findById(technicianId);
        if (!technician) {
            return res.status(404).json({ message: 'Technician not found' });
        }

        const review = await Review.create({
            customerId: req.user.id,
            technicianId,
            bookingId,
            rating,
            comment
        });

        await review.populate('customerId', 'name avatar');

        res.status(201).json({
            success: true,
            data: review
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Get reviews for technician
// @route   GET /api/reviews/:technicianId
// @access  Public
exports.getTechnicianReviews = async (req, res, next) => {
    try {
        const { page = 1, limit = 10 } = req.query;

        const pageNum = parseInt(page);
        const limitNum = parseInt(limit);
        const skip = (pageNum - 1) * limitNum;

        const reviews = await Review.find({ technicianId: req.params.technicianId })
            .populate('customerId', 'name avatar')
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(limitNum);

        const total = await Review.countDocuments({ technicianId: req.params.technicianId });

        // Get technician stats
        const stats = await Review.aggregate([
            { $match: { technicianId: require('mongoose').Types.ObjectId(req.params.technicianId) } },
            {
                $group: {
                    _id: null,
                    avgRating: { $avg: '$rating' },
                    totalReviews: { $sum: 1 }
                }
            }
        ]);

        res.json({
            success: true,
            count: reviews.length,
            total,
            page: pageNum,
            pages: Math.ceil(total / limitNum),
            stats: stats[0] || { avgRating: 0, totalReviews: 0 },
            data: reviews
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Get customer's reviews
// @route   GET /api/reviews/customer/my-reviews
// @access  Private (Customer)
exports.getMyReviews = async (req, res, next) => {
    try {
        const reviews = await Review.find({ customerId: req.user.id })
            .populate({
                path: 'technicianId',
                populate: { path: 'userId', select: 'name avatar' }
            })
            .sort({ createdAt: -1 });

        res.json({
            success: true,
            count: reviews.length,
            data: reviews
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Update review
// @route   PUT /api/reviews/:id
// @access  Private
exports.updateReview = async (req, res, next) => {
    try {
        const { rating, comment } = req.body;

        let review = await Review.findById(req.params.id);

        if (!review) {
            return res.status(404).json({ message: 'Review not found' });
        }

        // Only customer who wrote the review can update
        if (review.customerId.toString() !== req.user.id) {
            return res.status(403).json({ message: 'Not authorized to update this review' });
        }

        review.rating = rating;
        review.comment = comment;

        await review.save();

        res.json({
            success: true,
            data: review
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Delete review
// @route   DELETE /api/reviews/:id
// @access  Private
exports.deleteReview = async (req, res, next) => {
    try {
        const review = await Review.findById(req.params.id);

        if (!review) {
            return res.status(404).json({ message: 'Review not found' });
        }

        // Only customer who wrote the review or admin can delete
        if (review.customerId.toString() !== req.user.id && req.user.role !== 'admin') {
            return res.status(403).json({ message: 'Not authorized to delete this review' });
        }

        await review.deleteOne();

        res.json({
            success: true,
            message: 'Review deleted successfully'
        });
    } catch (error) {
        next(error);
    }
};
