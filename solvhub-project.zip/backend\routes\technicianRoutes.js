const express = require('express');
const router = express.Router();
const {
    getTechnicians,
    getTechnician,
    createTechnician,
    updateTechnician,
    getMyProfile,
    updateAvailability
} = require('../controllers/technicianController');
const { protect } = require('../middleware/authMiddleware');
const { authorize } = require('../middleware/roleMiddleware');

// Public routes
router.get('/', getTechnicians);
router.get('/:id', getTechnician);

// Protected routes
router.get('/me/profile', protect, authorize('technician'), getMyProfile);
router.post('/', protect, authorize('technician'), createTechnician);
router.put('/:id', protect, authorize('technician'), updateTechnician);
router.put('/availability/status', protect, authorize('technician'), updateAvailability);

module.exports = router;
