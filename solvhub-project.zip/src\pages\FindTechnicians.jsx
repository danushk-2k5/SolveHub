import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
    Search,
    MapPin,
    Star,
    Phone,
    Clock,
    CheckCircle,
    Filter,
    Zap,
    Droplets,
    Hammer,
    Paintbrush,
    Wrench,
    Home,
    Car,
    Scissors,
    ChefHat,
    Calendar,
    ArrowRight,
    Laptop,
    Trees,
    Bug,
    Sofa,
    Wind,
    Flame
} from 'lucide-react';

// Static service categories
const categories = [
    { id: 'all', name: 'All Services', icon: Wrench },
    { id: 'electrician', name: 'Electrician', icon: Zap },
    { id: 'plumber', name: 'Plumber', icon: Droplets },
    { id: 'carpenter', name: 'Carpenter', icon: Hammer },
    { id: 'painter', name: 'Painter', icon: Paintbrush },
    { id: 'mechanic', name: 'Mechanic', icon: Car },
    { id: 'cleaning', name: 'Cleaning', icon: Home },
    { id: 'beauty', name: 'Beauty & Spa', icon: Scissors },
    { id: 'cooking', name: 'Cooking', icon: ChefHat },
    { id: 'technician', name: 'Technician', icon: Laptop },
    { id: 'pest_control', name: 'Pest Control', icon: Bug },
    { id: 'gardening', name: 'Gardening', icon: Trees },
    { id: 'appliance', name: 'Appliance', icon: Flame },
];

// Static technician data
const staticTechnicians = [
    {
        _id: '1',
        name: 'Ramesh Kumar',
        serviceType: 'Electrician',
        category: 'electrician',
        rating: 4.8,
        totalReviews: 127,
        experience: 8,
        hourlyRate: 350,
        location: 'Anna Nagar, Chennai',
        distance: '2.5 km',
        image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop',
        skills: ['Wiring', 'Switch Repair', 'Fan Installation', 'Inverter Setup'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43210',
        description: 'Expert electrician with 8+ years experience in residential and commercial electrical work. Specializes in wiring, switch repairs, and inverter installations.'
    },
    {
        _id: '2',
        name: 'Suresh Patel',
        serviceType: 'Plumber',
        category: 'plumber',
        rating: 4.6,
        totalReviews: 89,
        experience: 6,
        hourlyRate: 300,
        location: 'T Nagar, Chennai',
        distance: '3.2 km',
        image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop',
        skills: ['Pipe Fitting', 'Leak Repair', 'Bathroom Fitting', 'Water Heater'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43211',
        description: 'Professional plumber specializing in bathroom fittings, pipe repairs, and water heater installations. Quick response time and quality service guaranteed.'
    },
    {
        _id: '3',
        name: 'Mohammed Ali',
        serviceType: 'Carpenter',
        category: 'carpenter',
        rating: 4.9,
        totalReviews: 156,
        experience: 12,
        hourlyRate: 400,
        location: 'Adyar, Chennai',
        distance: '4.1 km',
        image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop',
        skills: ['Furniture Making', 'Door Repair', 'Cabinet Work', 'Wood Polishing'],
        isAvailable: false,
        verified: true,
        phone: '+91 98765 43212',
        description: 'Master carpenter with 12 years of craftsmanship experience. Expert in custom furniture, door repairs, and intricate woodwork. Premium quality assured.'
    },
    {
        _id: '4',
        name: 'Priya Sharma',
        serviceType: 'Painter',
        category: 'painter',
        rating: 4.7,
        totalReviews: 73,
        experience: 5,
        hourlyRate: 280,
        location: 'Velachery, Chennai',
        distance: '1.8 km',
        image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop',
        skills: ['Interior Painting', 'Exterior Painting', 'Texture Work', 'Wallpaper'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43213',
        description: 'Creative painter specializing in interior and exterior painting. Expert in texture work and modern painting techniques. Clean and professional service.'
    },
    {
        _id: '5',
        name: 'Venkatesh Rao',
        serviceType: 'AC Technician',
        category: 'electrician',
        rating: 4.5,
        totalReviews: 94,
        experience: 7,
        hourlyRate: 450,
        location: 'Guindy, Chennai',
        distance: '5.3 km',
        image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=400&fit=crop',
        skills: ['AC Installation', 'AC Repair', 'Gas Refilling', 'Annual Maintenance'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43214',
        description: 'Certified AC technician with expertise in all major brands. Specializes in installation, repair, and maintenance of air conditioning systems.'
    },
    {
        _id: '6',
        name: 'Lakshmi Devi',
        serviceType: 'Home Cleaning',
        category: 'cleaning',
        rating: 4.8,
        totalReviews: 203,
        experience: 4,
        hourlyRate: 200,
        location: 'Mylapore, Chennai',
        distance: '3.7 km',
        image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop',
        skills: ['Deep Cleaning', 'Kitchen Cleaning', 'Bathroom Cleaning', 'Sofa Cleaning'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43215',
        description: 'Professional home cleaning expert. Provides deep cleaning, kitchen, bathroom, and sofa cleaning services. Uses eco-friendly cleaning products.'
    },
    {
        _id: '7',
        name: 'Arun Kumar',
        serviceType: 'Car Mechanic',
        category: 'mechanic',
        rating: 4.6,
        totalReviews: 112,
        experience: 9,
        hourlyRate: 500,
        location: 'Porur, Chennai',
        distance: '6.2 km',
        image: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400&h=400&fit=crop',
        skills: ['Car Service', 'Engine Repair', 'Brake Service', 'Oil Change'],
        isAvailable: false,
        verified: true,
        phone: '+91 98765 43216',
        description: 'Experienced auto mechanic specializing in all car brands. Expert in engine repairs, brake service, and regular maintenance. Doorstep service available.'
    },
    {
        _id: '8',
        name: 'Sunita Patel',
        serviceType: 'Beautician',
        category: 'beauty',
        rating: 4.9,
        totalReviews: 178,
        experience: 6,
        hourlyRate: 350,
        location: 'Kodambakkam, Chennai',
        distance: '2.9 km',
        image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=400&fit=crop',
        skills: ['Facial', 'Hair Styling', 'Manicure', 'Pedicure', 'Makeup'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43217',
        description: 'Professional beautician offering salon services at your home. Expert in facials, hair styling, manicure, pedicure, and bridal makeup.'
    },
    {
        _id: '9',
        name: 'Karthik Subramani',
        serviceType: 'Catering',
        category: 'cooking',
        rating: 4.7,
        totalReviews: 85,
        experience: 10,
        hourlyRate: 600,
        location: 'Alwarpet, Chennai',
        distance: '4.5 km',
        image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400&h=400&fit=crop',
        skills: ['South Indian', 'North Indian', 'Chinese', 'Party Catering', 'Tiffin Service'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43218',
        description: 'Professional chef with 10 years experience in multi-cuisine cooking. Specializes in South Indian, North Indian, and Chinese cuisine. Available for parties and daily tiffin.'
    },
    // More technicians from various Indian cities
    {
        _id: '10',
        name: 'Amit Sharma',
        serviceType: 'AC Technician',
        category: 'technician',
        rating: 4.6,
        totalReviews: 156,
        experience: 8,
        hourlyRate: 500,
        location: 'Andheri West, Mumbai',
        distance: '3.2 km',
        image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop',
        skills: ['AC Installation', 'AC Repair', 'Gas Refilling', 'AMC Services'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43219',
        description: 'Expert AC technician in Mumbai. Authorized service provider for all major brands. Quick turnaround and doorstep service.'
    },
    {
        _id: '11',
        name: 'Rahul Verma',
        serviceType: 'Plumber',
        category: 'plumber',
        rating: 4.5,
        totalReviews: 98,
        experience: 5,
        hourlyRate: 350,
        location: 'Connaught Place, Delhi',
        distance: '1.5 km',
        image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop',
        skills: ['Pipe Fitting', 'Leak Repair', 'Bathroom Renovation', 'Water Tank Cleaning'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43220',
        description: 'Professional plumber in Delhi NCR. Expert in all types of plumbing work. Available for emergency services.'
    },
    {
        _id: '12',
        name: 'Sandeep Reddy',
        serviceType: 'Electrician',
        category: 'electrician',
        rating: 4.8,
        totalReviews: 234,
        experience: 12,
        hourlyRate: 450,
        location: 'Banjara Hills, Hyderabad',
        distance: '2.8 km',
        image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop',
        skills: ['Wiring', 'Switchboard', 'Inverter', 'Solar Panel Installation'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43221',
        description: 'Senior electrician with expertise in modern electrical systems. Specializes in home wiring and commercial electrical work.'
    },
    {
        _id: '13',
        name: 'Prakash Jha',
        serviceType: 'Pest Control',
        category: 'pest_control',
        rating: 4.7,
        totalReviews: 167,
        experience: 7,
        hourlyRate: 600,
        location: 'Salt Lake, Kolkata',
        distance: '4.1 km',
        image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=400&fit=crop',
        skills: ['Cockroach Control', 'Termite Treatment', 'Bed Bug Removal', 'Rodent Control'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43222',
        description: 'Certified pest control expert using safe and eco-friendly treatments. Comprehensive pest management solutions.'
    },
    {
        _id: '14',
        name: 'Nikhil Joshi',
        serviceType: 'Home Cleaning',
        category: 'cleaning',
        rating: 4.9,
        totalReviews: 312,
        experience: 5,
        hourlyRate: 250,
        location: 'Koregaon Park, Pune',
        distance: '2.3 km',
        image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop',
        skills: ['Deep Cleaning', 'Sanitization', 'Carpet Cleaning', 'Office Cleaning'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43223',
        description: 'Professional cleaning services in Pune. Trained staff using modern equipment and eco-friendly products.'
    },
    {
        _id: '15',
        name: 'Deepak Gowda',
        serviceType: 'Carpenter',
        category: 'carpenter',
        rating: 4.6,
        totalReviews: 145,
        experience: 15,
        hourlyRate: 500,
        location: 'MG Road, Bangalore',
        distance: '3.7 km',
        image: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400&h=400&fit=crop',
        skills: ['Furniture Making', 'Modular Kitchen', 'Wardrobe', 'Wood Polishing'],
        isAvailable: false,
        verified: true,
        phone: '+91 98765 43224',
        description: 'Master carpenter with expertise in modern furniture and modular kitchens. Quality craftsmanship guaranteed.'
    },
    {
        _id: '16',
        name: 'Vijay Malhotra',
        serviceType: 'Painter',
        category: 'painter',
        rating: 4.5,
        totalReviews: 89,
        experience: 6,
        hourlyRate: 350,
        location: 'Gurgaon Sector 56',
        distance: '5.2 km',
        image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop',
        skills: ['Interior Painting', 'Exterior Painting', 'Texture', 'Waterproofing'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43225',
        description: 'Expert painter in Gurgaon. Specializes in Asian Paints and Berger paints application. Clean and professional work.'
    },
    {
        _id: '17',
        name: 'Anjali Iyer',
        serviceType: 'Beautician',
        category: 'beauty',
        rating: 4.8,
        totalReviews: 256,
        experience: 8,
        hourlyRate: 450,
        location: 'Jubilee Hills, Hyderabad',
        distance: '4.5 km',
        image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=400&fit=crop',
        skills: ['Bridal Makeup', 'Hair Styling', 'Facial', 'Mehendi'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43226',
        description: 'Professional beautician in Hyderabad. Expert in bridal makeup and traditional Indian beauty services.'
    },
    {
        _id: '18',
        name: 'Raj Singh',
        serviceType: 'Car Mechanic',
        category: 'mechanic',
        rating: 4.7,
        totalReviews: 189,
        experience: 11,
        hourlyRate: 600,
        location: 'Janakpuri, Delhi',
        distance: '2.9 km',
        image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400&h=400&fit=crop',
        skills: ['Engine Repair', 'Transmission', 'Brake Service', 'Denting Painting'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43227',
        description: 'Expert car mechanic in Delhi. Specializes in all car brands. Provides doorstep service and pickup-drop.'
    },
    {
        _id: '19',
        name: 'Manish Kumar',
        serviceType: 'Refrigerator Technician',
        category: 'appliance',
        rating: 4.6,
        totalReviews: 134,
        experience: 7,
        hourlyRate: 400,
        location: 'Vijayanagar, Bangalore',
        distance: '3.1 km',
        image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop',
        skills: ['Refrigerator Repair', 'Washing Machine', 'Microwave', 'Dishwasher'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43228',
        description: 'Appliance repair expert in Bangalore. Authorized service center for all major brands.'
    },
    {
        _id: '20',
        name: 'Kiran Patel',
        serviceType: 'Gardener',
        category: 'gardening',
        rating: 4.4,
        totalReviews: 67,
        experience: 4,
        hourlyRate: 300,
        location: 'Vastrapur, Ahmedabad',
        distance: '2.4 km',
        image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop',
        skills: ['Lawn Maintenance', 'Plant Care', 'Landscaping', 'Vertical Gardens'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43229',
        description: 'Professional gardener in Ahmedabad. Creates beautiful gardens and maintains existing landscapes.'
    },
    {
        _id: '21',
        name: 'Sanjay Thakur',
        serviceType: 'Chef',
        category: 'cooking',
        rating: 4.9,
        totalReviews: 178,
        experience: 12,
        hourlyRate: 800,
        location: 'Powai, Mumbai',
        distance: '5.8 km',
        image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=400&fit=crop',
        skills: ['Biryani Specialist', 'Mughlai', 'Italian', 'Continental'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43230',
        description: 'Expert chef for parties and events. Specializes in Indian cuisine and international dishes.'
    },
    {
        _id: '22',
        name: 'Ravi Teja',
        serviceType: 'TV Technician',
        category: 'appliance',
        rating: 4.5,
        totalReviews: 112,
        experience: 6,
        hourlyRate: 350,
        location: 'Ameerpet, Hyderabad',
        distance: '1.9 km',
        image: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400&h=400&fit=crop',
        skills: ['LED Repair', 'LCD Repair', 'Smart TV Setup', 'Wall Mounting'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43231',
        description: 'TV and LED/LCD repair specialist. Quick service at your doorstep in Hyderabad.'
    },
    {
        _id: '23',
        name: 'Fatima Sheikh',
        serviceType: 'Sofa Cleaning',
        category: 'cleaning',
        rating: 4.7,
        totalReviews: 198,
        experience: 5,
        hourlyRate: 400,
        location: 'Bandra West, Mumbai',
        distance: '3.6 km',
        image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=400&fit=crop',
        skills: ['Sofa Cleaning', 'Carpet Cleaning', 'Mattress Cleaning', 'Curtain Cleaning'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43232',
        description: 'Professional deep cleaning services in Mumbai. Uses advanced steam cleaning technology.'
    },
    {
        _id: '24',
        name: 'Omar Khan',
        serviceType: 'Pest Control',
        category: 'pest_control',
        rating: 4.6,
        totalReviews: 145,
        experience: 8,
        hourlyRate: 550,
        location: 'Whitefield, Bangalore',
        distance: '4.2 km',
        image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop',
        skills: ['Termite Control', 'Mosquito Control', 'Pigeon Control', 'General Pest'],
        isAvailable: true,
        verified: true,
        phone: '+91 98765 43233',
        description: 'Eco-friendly pest control in Bangalore. Safe for pets and children. 100% satisfaction guarantee.'
    }
];

const FindTechnicians = () => {
    const [selectedCategory, setSelectedCategory] = useState('all');
    const [searchQuery, setSearchQuery] = useState('');
    const [showFilters, setShowFilters] = useState(false);
    const [visibleCount, setVisibleCount] = useState(9);
    const [loadingMore, setLoadingMore] = useState(false);
    const ITEMS_PER_PAGE = 9;

    // Filter technicians based on category and search
    const filteredTechnicians = staticTechnicians.filter(tech => {
        const matchesCategory = selectedCategory === 'all' || tech.category === selectedCategory;
        const matchesSearch = tech.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            tech.serviceType.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            tech.location.toLowerCase().includes(searchQuery.toLowerCase());
        return matchesCategory && matchesSearch;
    });

    // Get visible technicians based on pagination
    const visibleTechnicians = filteredTechnicians.slice(0, visibleCount);
    const hasMore = visibleCount < filteredTechnicians.length;

    const handleLoadMore = () => {
        setLoadingMore(true);
        setTimeout(() => {
            setVisibleCount(prev => prev + ITEMS_PER_PAGE);
            setLoadingMore(false);
        }, 500);
    };

    return (
        <div className="min-h-screen bg-gray-50">
            {/* Hero Section */}
            <div className="bg-gradient-to-r from-primary-600 to-primary-800 text-white py-12">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <h1 className="text-3xl md:text-4xl font-bold mb-4">
                        Find Local Service Providers
                    </h1>
                    <p className="text-primary-100 text-lg mb-8">
                        Connect with verified professionals for all your home service needs
                    </p>

                    {/* Search Bar */}
                    <div className="max-w-2xl">
                        <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                <Search className="h-5 w-5 text-gray-400" />
                            </div>
                            <input
                                type="text"
                                placeholder="Search by name, service, or location..."
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                className="w-full pl-12 pr-4 py-4 rounded-xl text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-white/50"
                            />
                            <button
                                onClick={() => setShowFilters(!showFilters)}
                                className="absolute right-3 top-1/2 transform -translate-y-1/2 p-2 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
                            >
                                <Filter className="h-5 w-5 text-gray-600" />
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            {/* Categories */}
            <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex space-x-2 overflow-x-auto py-4 scrollbar-hide">
                        {categories.map((category) => {
                            const Icon = category.icon;
                            return (
                                <button
                                    key={category.id}
                                    onClick={() => setSelectedCategory(category.id)}
                                    className={`flex items-center space-x-2 px-4 py-2 rounded-full whitespace-nowrap transition-all ${
                                        selectedCategory === category.id
                                            ? 'bg-primary-600 text-white shadow-md'
                                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                                    }`}
                                >
                                    <Icon className="w-4 h-4" />
                                    <span className="text-sm font-medium">{category.name}</span>
                                </button>
                            );
                        })}
                    </div>
                </div>
            </div>

            {/* Results Section */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                {/* Results Count */}
                <div className="mb-6 flex items-center justify-between">
                    <h2 className="text-xl font-semibold text-gray-900">
                        {filteredTechnicians.length} Service Providers Available
                    </h2>
                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                        <MapPin className="w-4 h-4" />
                        <span>All India</span>
                    </div>
                </div>

                {/* Technician Cards Grid */}
                {filteredTechnicians.length === 0 ? (
                    <div className="text-center py-12">
                        <div className="text-6xl mb-4">🔍</div>
                        <h3 className="text-lg font-medium text-gray-900 mb-2">No service providers found</h3>
                        <p className="text-gray-600">Try adjusting your search or category filter</p>
                    </div>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {visibleTechnicians.map((tech) => (
                            <div
                                key={tech._id}
                                className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-lg transition-all duration-300 group"
                            >
                                {/* Card Header with Image */}
                                <div className="relative h-48 overflow-hidden">
                                    <img
                                        src={tech.image}
                                        alt={tech.name}
                                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                    />
                                    <div className="absolute top-4 left-4">
                                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                                            tech.isAvailable
                                                ? 'bg-green-500 text-white'
                                                : 'bg-gray-500 text-white'
                                        }`}>
                                            {tech.isAvailable ? 'Available' : 'Busy'}
                                        </span>
                                    </div>
                                    {tech.verified && (
                                        <div className="absolute top-4 right-4">
                                            <span className="px-3 py-1 bg-blue-500 text-white rounded-full text-xs font-medium flex items-center space-x-1">
                                                <CheckCircle className="w-3 h-3" />
                                                <span>Verified</span>
                                            </span>
                                        </div>
                                    )}
                                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-4">
                                        <h3 className="text-white font-semibold text-lg">{tech.name}</h3>
                                        <p className="text-white/90 text-sm">{tech.serviceType}</p>
                                    </div>
                                </div>

                                {/* Card Body */}
                                <div className="p-5">
                                    {/* Rating & Experience */}
                                    <div className="flex items-center justify-between mb-4">
                                        <div className="flex items-center space-x-1">
                                            <Star className="w-5 h-5 text-yellow-400 fill-current" />
                                            <span className="font-semibold text-gray-900">{tech.rating}</span>
                                            <span className="text-gray-500 text-sm">({tech.totalReviews})</span>
                                        </div>
                                        <div className="flex items-center text-gray-600 text-sm">
                                            <Clock className="w-4 h-4 mr-1" />
                                            {tech.experience} years
                                        </div>
                                    </div>

                                    {/* Location */}
                                    <div className="flex items-center text-gray-600 text-sm mb-3">
                                        <MapPin className="w-4 h-4 mr-2 text-primary-600" />
                                        <span>{tech.location}</span>
                                        <span className="mx-2 text-gray-300">|</span>
                                        <span>{tech.distance}</span>
                                    </div>

                                    {/* Skills */}
                                    <div className="flex flex-wrap gap-2 mb-4">
                                        {tech.skills.slice(0, 3).map((skill, index) => (
                                            <span
                                                key={index}
                                                className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-md"
                                            >
                                                {skill}
                                            </span>
                                        ))}
                                        {tech.skills.length > 3 && (
                                            <span className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-md">
                                                +{tech.skills.length - 3}
                                            </span>
                                        )}
                                    </div>

                                    {/* Description */}
                                    <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                                        {tech.description}
                                    </p>

                                    {/* Price & Actions */}
                                    <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                                        <div>
                                            <span className="text-2xl font-bold text-gray-900">₹{tech.hourlyRate}</span>
                                            <span className="text-gray-500 text-sm">/hr</span>
                                        </div>
                                        <div className="flex space-x-2">
                                            <a
                                                href={`tel:${tech.phone}`}
                                                className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                                                title="Call"
                                            >
                                                <Phone className="w-5 h-5 text-gray-600" />
                                            </a>
                                            <Link
                                                to={`/book/${tech._id}`}
                                                className="flex items-center space-x-2 px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors"
                                            >
                                                <Calendar className="w-4 h-4" />
                                                <span>Book</span>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                )}

                {/* Load More */}
                {filteredTechnicians.length > 0 && hasMore && (
                    <div className="text-center mt-8">
                        <button 
                            onClick={handleLoadMore}
                            disabled={loadingMore}
                            className="inline-flex items-center space-x-2 px-6 py-3 border border-gray-300 rounded-xl text-gray-700 font-medium hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            {loadingMore ? (
                                <>
                                    <div className="w-4 h-4 border-2 border-gray-400 border-t-transparent rounded-full animate-spin"></div>
                                    <span>Loading...</span>
                                </>
                            ) : (
                                <>
                                    <span>Load More</span>
                                    <ArrowRight className="w-4 h-4" />
                                </>
                            )}
                        </button>
                    </div>
                )}
                {/* Showing count */}
                {filteredTechnicians.length > 0 && !hasMore && (
                    <div className="text-center mt-8 text-gray-500">
                        <p>Showing all {filteredTechnicians.length} service providers</p>
                    </div>
                )}
            </div>

            {/* Trust Badges */}
            <div className="bg-white border-t border-gray-200 py-8">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
                        <div>
                            <div className="text-3xl font-bold text-primary-600 mb-1">{staticTechnicians.length}+</div>
                            <div className="text-gray-600 text-sm">Verified Experts</div>
                        </div>
                        <div>
                            <div className="text-3xl font-bold text-primary-600 mb-1">10k+</div>
                            <div className="text-gray-600 text-sm">Services Completed</div>
                        </div>
                        <div>
                            <div className="text-3xl font-bold text-primary-600 mb-1">4.8</div>
                            <div className="text-gray-600 text-sm">Average Rating</div>
                        </div>
                        <div>
                            <div className="text-3xl font-bold text-primary-600 mb-1">30 min</div>
                            <div className="text-gray-600 text-sm">Avg. Response Time</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default FindTechnicians;