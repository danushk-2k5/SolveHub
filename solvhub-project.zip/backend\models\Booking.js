const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
    customerId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    technicianId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Technician',
        required: true
    },
    serviceType: {
        type: String,
        required: [true, 'Please specify the service type']
    },
    description: {
        type: String,
        required: [true, 'Please provide a service description'],
        maxlength: [1000, 'Description cannot be more than 1000 characters']
    },
    bookingDate: {
        type: Date,
        required: [true, 'Please select a date']
    },
    bookingTime: {
        type: String,
        required: [true, 'Please select a time']
    },
    location: {
        address: { type: String, required: true },
        coordinates: {
            type: [Number],  // [longitude, latitude]
            index: '2dsphere'
        }
    },
    status: {
        type: String,
        enum: ['pending', 'accepted', 'in_progress', 'completed', 'cancelled'],
        default: 'pending'
    },
    acceptedAt: {
        type: Date
    },
    completedAt: {
        type: Date
    },
    cancelledAt: {
        type: Date
    },
    cancellationReason: {
        type: String
    },
    estimatedCost: {
        type: Number,
        default: 0
    },
    finalCost: {
        type: Number,
        default: 0
    },
    notes: String,
    customerNotes: String,
    technicianNotes: String
}, { timestamps: true });

// Index for geospatial queries - removed duplicate, already defined in schema above
bookingSchema.index({ customerId: 1, createdAt: -1 });
bookingSchema.index({ technicianId: 1, createdAt: -1 });

module.exports = mongoose.model('Booking', bookingSchema);
